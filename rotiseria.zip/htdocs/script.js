function mostrarSeccion(id) {
      document.querySelectorAll("section").forEach(sec => {
        sec.classList.remove("active");
      });
      document.getElementById(id).classList.add("active");
    }

document.getElementById("volver").addEventListener("click", () => mostrarSeccion("menu"));

function mostrarSeccion(id) {
    document.querySelectorAll("section").forEach(sec => {
        sec.classList.remove("active");
    })
    document.getElementById(id).classList.add("active");
}

document.getElementById("graficaButton").addEventListener("click", () => mostrarSeccion("grafica"))


document.addEventListener("DOMContentLoaded", () => {
    const botones = document.querySelectorAll(".comboBox");

    botones.forEach(btn => {
        const popup = btn.querySelector(".popup");
        if (!popup) return;

        const closeBtn = popup.querySelector(".close");

        //abrir popup al hacer click
        btn.addEventListener("click", (e) => {
            e.stopPropagation();

            // solo se cierra con la X
            if (!popup.classList.contains("show")) {
                popup.classList.remove("hidden");
                setTimeout(() => popup.classList.add("show"), 10);
            }
        });

        // cerrar
        closeBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            popup.classList.remove("show");
            setTimeout(() => popup.classList.add("hidden"), 300);
        });
    });
});





