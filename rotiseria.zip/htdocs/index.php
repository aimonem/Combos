<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>

    <title>BifeConJuguito</title>
</head>
<body>
    
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servidor = "sql213.infinityfree.com";
$usuario = "if0_40486004";
$contraseña = "IsBHC8fD4L2kL";
$baseDeDatos = "if0_40486004_rotiseria_db";

$conexion = mysqli_connect($servidor, $usuario, $contraseña, $baseDeDatos);

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["voto"])) {

    $comboElegido = $_POST["voto"];

    $sqlUpdate = "UPDATE Combos SET Cant_votos = Cant_votos + 1 WHERE Combo = '$comboElegido'";

    mysqli_query($conexion, $sqlUpdate);

    $mensaje = "Tu pedido fue registrado: $comboElegido";

    echo "<script>
            alert('$mensaje');
            window.location.href = '".$_SERVER['PHP_SELF']."';
          </script>";
    exit;
}

$sql = "SELECT Combo, Cant_votos FROM Combos";
$consulta = mysqli_query($conexion, $sql);

$labels = [];
$data = [];

if ($consulta->num_rows > 0) {
    while ($fila = $consulta->fetch_assoc()) {
        $labels[] = $fila['Combo'];
        $data[] = $fila['Cant_votos'];
    }
}
?>

    <section id="menu" class="menu active">
        <div class="titles">
            <img src="img/logo.png" alt="logo">
            <h1> PedidosYa </h1>
            <h2> Menú </h2>
        </div>

        <form method="post" action="">
            <div class="combosRow"> 
                <button id="Lainsuperable" class="comboBox buttons">
                    <div class="combo">
                        <img src="img/burguer.jpeg" alt="foto la insuperable">
                        <span> La Insuperable </span>
                    </div>
                    <div id="popupInsuperable" class="popup hidden">
                        <div class="popup-content">
                            <span class="close">&times;</span>
                            <h2> Combo La Insuperable</h2>
                            <p>
                                Doble medallón de carne, cheddar fundido, panceta crocante, cebolla
                                caramelizada y salsa especial. Incluye papas y bebida.
                            </p>
                            <div class="casilla">
                                <input type="radio" name="voto" value="La Insuperable" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </button>
                

                <button id="Lafinoli" class="comboBox buttons">
                    <div class="combo">
                        <img src="img/burguer.jpeg" alt="foto la insuperable">
                        <span> La Finoli </span>
                    </div>
                    <div id="popupFinoli" class="popup hidden">
                        <div class="popup-content">
                            <span class="close">&times;</span>
                            <h2> Combo La Finoli</h2>
                            <p>
                                Cuenta con 4 Medallones de pescado con ensalada de apio + 1 levite
                                sabor pomelo y de postre 2 mouffins de tofu
                            </p>
                            <div class="casilla">
                                <input type="radio" name="voto" value="La Finoli" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </button>

                <button id="Lapesada" class="comboBox buttons">
                    <div class="combo">
                        <img src="img/burguer.jpeg" alt="foto la insuperable">
                        <span> La Pesada </span>
                    </div>
                    <div id="popupPesada" class="popup hidden">
                        <div class="popup-content">
                            <span class="close">&times;</span>
                            <h2> Combo La Pesada</h2>
                            <p>
                                Cuenta con 4 bombas de papa de queso + 2 porción de tarta de queso + 2 chuleta jugosa y de postre 2 porciones de torta selva negra
                            </p>
                            <div class="casilla">
                                <input type="radio" name="voto" value="La Pesada" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </button>

            </div>
            
            <div class="combosRow2">
                <button id="sopa" class="comboBox buttons">
                    <div class="combo">
                        <img src="img/burguer.jpeg" alt="foto la insuperable">
                        <span> Sopa de Tubo </span>
                    </div>
                    <div id="popupSopa" class="popup hidden">
                        <div class="popup-content">
                            <span class="close">&times;</span>
                            <h2> Combo Sopa de Tubo</h2>
                            <p>
                               Cuenta con 2 Sopas de verduras de la estación que tuvo carne pero se la sacaron y de postre 1 flan casero
                            </p>
                            <div class="casilla">
                                <input type="radio" name="voto" value="Sopa de Tubo" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </button>

                <button id="Elpatriota" class="comboBox buttons">
                    <div class="combo">
                        <img src="img/burguer.jpeg" alt="foto el patriota ">
                        <span> El patriota </span>
                    </div>
                    <div id="popupPatriota" class="popup hidden">
                        <div class="popup-content">
                            <span class="close">&times;</span>
                            <h2> Combo El Patriota</h2>
                            <p>
                               Cuenta con media docena de empanada de carne + 1 gaseosa y de postre queso con membrillo
                            </p>
                            <div class="casilla">
                                <input type="radio" name="voto" value="El patriota" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </button>

                <button id="LaDiablo" class="comboBox buttons">
                    <div class="combo">
                        <img src="img/burguer.jpeg" alt="foto la diablo">
                        <span> La Diablo Ácido </span>
                    </div>
                    <div id="popupDiablo" class="popup hidden">
                        <div class="popup-content">
                            <span class="close">&times;</span>
                            <h2> Combo La diablo</h2>
                            <p>
                              Cuenta con 2 Hamburguesas extra picantes + 1 gaseosa y de postre humus sabor panceta
                            </p>
                            <div class="casilla">
                                <input type="radio" name="voto" value="La Diablo" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </button>
            </div>

        <div class="button">

        <button type= "submit" id="OrdenButton" class="ordenButton buttons"> Ordenar </button>
        <button id="graficaButton" class="graficaButton buttons"> Datos de votos </button>
        
        </div>
    </form>
    </section>
    

    <section id="grafica" class="grafica">
        <img id="volver" class="volver" src="img/volver.png" alt="boton volver">
        <div class="canva">
            <canvas id="graficos" width="800px" height="500px"> </canvas>
			<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script> 
                var labels = <?php echo json_encode($labels); ?>;
                var data = <?php echo json_encode($data); ?>;

                var ctx = document.getElementById('graficos').getContext('2d');

                console.log("labels:", labels);
                console.log("data:", data);

                var myChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: '# de votos',
                            data: data,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.6)',
                                'rgba(153, 102, 255, 0.6)',
                                'rgba(75, 192, 192, 0.6)',
                                'rgba(255, 205, 86, 0.6)',
                                'rgba(255, 159, 243, 0.6)',
                                'rgba(102, 255, 0, 0.6)'
                            ],
                            borderColor: [
                                'rgba(255, 99, 132, 1)',
                                'rgba(153, 102, 255, 1)',
                                'rgba(75, 192, 192, 1)',
                                'rgba(255, 205, 86, 1)',
                                'rgba(255, 159, 243, 1)',
                                'rgba(173, 255, 47, 1)'
                            ],
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: false,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            </script>
        </div>
    </section>

</body>
</html>